(function () {
  'use strict';
  var cfg = window.GACEB_CONFIG || {};
  if (!window.supabase || !cfg.SUPABASE_URL || !cfg.SUPABASE_ANON_KEY) return;
  var db = window.supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY);
  var box = document.getElementById('assistantMessages');
  var form = document.getElementById('assistantForm');
  var input = document.getElementById('assistantInput');
  if (!box || !form || !input) return;
  var hist = [], busy = false;

  function add(txt, cls) {
    var d = document.createElement('div');
    d.className = 'message ' + cls;
    d.textContent = txt;
    box.appendChild(d);
    box.scrollTop = box.scrollHeight;
  }
  function typing() {
    var d = document.createElement('div');
    d.className = 'message bot typing';
    d.innerHTML = '<span></span><span></span><span></span>';
    box.appendChild(d);
    box.scrollTop = box.scrollHeight;
    return d;
  }

  document.addEventListener('submit', async function (e) {
    if (e.target !== form) return;
    e.preventDefault();
    e.stopImmediatePropagation();
    var t = input.value.trim();
    if (!t || busy) return;
    input.value = '';
    add(t, 'user');
    var ty = typing();
    busy = true;
    try {
      var s = await db.auth.getSession();
      if (!s.data || !s.data.session) {
        ty.remove();
        add('Please log in to chat with me. It is free and only takes a moment.', 'bot');
        return;
      }
      var msgs = hist.concat([{ role: 'user', content: t }]).slice(-8);
      var r = await db.functions.invoke('gauge-assistant', { body: { messages: msgs } });
      ty.remove();
      if (r.data && r.data.reply) {
        hist.push({ role: 'user', content: t }, { role: 'assistant', content: r.data.reply });
        add(r.data.reply, 'bot');
        return;
      }
      var m = '';
      try { var j = await r.error.context.json(); m = j.error || ''; } catch (x) {}
      add(m || 'Sorry, I could not answer just now. Please try again in a moment.', 'bot');
    } catch (x) {
      ty.remove();
      add('Sorry, I could not answer just now. Please try again in a moment.', 'bot');
    } finally {
      busy = false;
    }
  }, true);

  var clr = document.getElementById('clearChat');
  if (clr) clr.addEventListener('click', function () { hist.length = 0; });
})();
